package com.example.myapplication;

public class Ratings {
    private String description;
    private Integer stars;
}
