package com.example.myapplication;

public class Tags {
    private String name;
    private Boolean isTrue;
}
